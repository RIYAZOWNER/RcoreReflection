package top.niunaijun.blackbox.reflection;

/**
 * Created by Milk on 2022/2/16.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public class RcoreNullPointerException extends NullPointerException {
    public RcoreNullPointerException(String s) {
        super(s);
    }
}
